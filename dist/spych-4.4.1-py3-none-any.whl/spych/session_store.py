"""
Session persistence for spych agent conversations.

Each invocation of a spych agent gets a UUID session ID.  The ID is used as
the filename under ``~/.config/spych/sessions/`` and the file records the
workspace path plus the underlying agent conversation ID so the session can
be resumed across restarts.
"""

import json
import os
import uuid
from typing import Optional

_SESSIONS_DIR = os.path.join(
    os.path.expanduser("~"), ".config", "spych", "sessions"
)


def _sessions_dir() -> str:
    """
    Usage:

    - Return the sessions directory path, creating it if needed.

    Returns:

    - `path`:
        - Type: str
        - What: Absolute path to ``~/.config/spych/sessions/``.
    """
    os.makedirs(_SESSIONS_DIR, exist_ok=True)
    return _SESSIONS_DIR


def _session_path(session_id: str) -> str:
    return os.path.join(_sessions_dir(), f"{session_id}.json")


def new_session_id() -> str:
    """
    Usage:

    - Generate a fresh UUID to use as a spych session ID for this invocation.

    Returns:

    - `session_id`:
        - Type: str
        - What: A new UUID4 string.
    """
    return str(uuid.uuid4())


def load_session(session_id: str) -> dict:
    """
    Usage:

    - Load a previously saved session by its UUID.

    Requires:

    - `session_id`:
        - Type: str
        - What: UUID of the session to load.

    Returns:

    - `data`:
        - Type: dict
        - What: Session data dict with keys ``session_id``, ``workspace``,
          ``conversation_id`` (may be None), and ``created_at``.

    Notes:

    - Returns an empty dict if the file does not exist or cannot be parsed.
    """
    path = _session_path(session_id)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def save_session(
    session_id: str, workspace: str, conversation_id: Optional[str]
) -> None:
    """
    Usage:

    - Persist a session's workspace and agent conversation ID to disk.

    Requires:

    - `session_id`:
        - Type: str
        - What: UUID of this spych session (used as the filename).

    - `workspace`:
        - Type: str
        - What: Absolute path to the workspace directory.

    - `conversation_id`:
        - Type: str | None
        - What: The agent's conversation ID to resume on the next run.

    Notes:

    - Overwrites any existing file for the same ``session_id``.
    """
    path = _session_path(session_id)
    existing = load_session(session_id)
    data = {
        "session_id": session_id,
        "workspace": workspace,
        "conversation_id": conversation_id,
        "created_at": existing.get("created_at") or _now_iso(),
        "updated_at": _now_iso(),
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def latest_session_for_workspace(workspace: str) -> Optional[str]:
    """
    Usage:

    - Find the most recently updated session ID for a given workspace.

    Requires:

    - `workspace`:
        - Type: str
        - What: Absolute path to the workspace directory.

    Returns:

    - `session_id`:
        - Type: str | None
        - What: The UUID of the most recent matching session, or None if no
          session exists for that workspace.
    """
    sessions_dir = _sessions_dir()
    best_id: Optional[str] = None
    best_mtime: float = -1.0

    try:
        entries = os.listdir(sessions_dir)
    except OSError:
        return None

    for fname in entries:
        if not fname.endswith(".json"):
            continue
        fpath = os.path.join(sessions_dir, fname)
        try:
            mtime = os.path.getmtime(fpath)
            with open(fpath, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if data.get("workspace") == workspace and mtime > best_mtime:
                best_mtime = mtime
                best_id = data.get("session_id")
        except Exception:
            continue

    return best_id


def _now_iso() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()
